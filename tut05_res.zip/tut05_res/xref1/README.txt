Instructor note:
================
This package contains the design specification and partial implementation of another Xref design, which includes one  
class for each of the program's concept. 

Students are to study the package and to complete the code by writing for each of the TODO comments. 